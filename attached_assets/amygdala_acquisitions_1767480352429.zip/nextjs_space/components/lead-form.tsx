'use client'

import { useState } from 'react'
import { Loader2, CheckCircle2 } from 'lucide-react'

export default function LeadForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    businessType: '',
    currentRevenue: '',
    mainChallenges: '',
    goals: '',
    howDidYouHear: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e?.target ?? {}
    setFormData((prev) => ({ ...(prev ?? {}), [name ?? '']: value ?? '' }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e?.preventDefault?.()
    setIsSubmitting(true)
    setError('')

    try {
      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })

      if (!response?.ok) {
        throw new Error('Failed to submit')
      }

      setIsSubmitted(true)
    } catch (err) {
      setError('Something went wrong. Please try again.')
      console.error('Form submission error:', err)
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isSubmitted) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
        <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h3>
        <p className="text-gray-600">
          We\'ve received your information and will be in touch within 24 hours with your personalized growth audit.
        </p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl p-8">
      <div className="space-y-5">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
            Full Name *
          </label>
          <input
            type="text"
            id="name"
            name="name"
            required
            value={formData?.name ?? ''}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-royal focus:border-transparent outline-none transition-all"
            placeholder="John Smith"
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
            Email Address *
          </label>
          <input
            type="email"
            id="email"
            name="email"
            required
            value={formData?.email ?? ''}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-royal focus:border-transparent outline-none transition-all"
            placeholder="john@company.com"
          />
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
            Phone Number
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData?.phone ?? ''}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-royal focus:border-transparent outline-none transition-all"
            placeholder="+44 7000 000000"
          />
        </div>

        <div>
          <label htmlFor="businessType" className="block text-sm font-medium text-gray-700 mb-1">
            Business Type *
          </label>
          <select
            id="businessType"
            name="businessType"
            required
            value={formData?.businessType ?? ''}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-royal focus:border-transparent outline-none transition-all bg-white"
          >
            <option value="">Select your business type</option>
            <option value="agency">Agency / Consultancy</option>
            <option value="saas">SaaS / Software</option>
            <option value="coaching">Coaching / Training</option>
            <option value="ecommerce">E-commerce</option>
            <option value="professional-services">Professional Services</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div>
          <label htmlFor="currentRevenue" className="block text-sm font-medium text-gray-700 mb-1">
            Current Monthly Revenue *
          </label>
          <select
            id="currentRevenue"
            name="currentRevenue"
            required
            value={formData?.currentRevenue ?? ''}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-royal focus:border-transparent outline-none transition-all bg-white"
          >
            <option value="">Select revenue range</option>
            <option value="0-10k">£0 - £10,000</option>
            <option value="10k-50k">£10,000 - £50,000</option>
            <option value="50k-100k">£50,000 - £100,000</option>
            <option value="100k-500k">£100,000 - £500,000</option>
            <option value="500k+">£500,000+</option>
          </select>
        </div>

        <div>
          <label htmlFor="mainChallenges" className="block text-sm font-medium text-gray-700 mb-1">
            Main Challenges *
          </label>
          <textarea
            id="mainChallenges"
            name="mainChallenges"
            required
            rows={3}
            value={formData?.mainChallenges ?? ''}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-royal focus:border-transparent outline-none transition-all resize-none"
            placeholder="What are the biggest obstacles to your growth right now?"
          />
        </div>

        <div>
          <label htmlFor="goals" className="block text-sm font-medium text-gray-700 mb-1">
            Growth Goals
          </label>
          <textarea
            id="goals"
            name="goals"
            rows={2}
            value={formData?.goals ?? ''}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-royal focus:border-transparent outline-none transition-all resize-none"
            placeholder="Where do you want to be in 6-12 months?"
          />
        </div>

        <div>
          <label htmlFor="howDidYouHear" className="block text-sm font-medium text-gray-700 mb-1">
            How did you hear about us?
          </label>
          <select
            id="howDidYouHear"
            name="howDidYouHear"
            value={formData?.howDidYouHear ?? ''}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-royal focus:border-transparent outline-none transition-all bg-white"
          >
            <option value="">Select an option</option>
            <option value="google">Google Search</option>
            <option value="social">Social Media</option>
            <option value="referral">Referral</option>
            <option value="podcast">Podcast</option>
            <option value="other">Other</option>
          </select>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-royal text-white py-4 rounded-lg font-semibold text-lg hover:bg-royal-dark transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Submitting...
            </>
          ) : (
            'Get My Free Audit'
          )}
        </button>

        <p className="text-xs text-gray-500 text-center">
          Your information is secure and will never be shared.
        </p>
      </div>
    </form>
  )
}
