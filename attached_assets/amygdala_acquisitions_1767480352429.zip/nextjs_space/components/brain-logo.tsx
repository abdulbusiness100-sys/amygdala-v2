export default function BrainLogo({ className = 'w-12 h-12' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <filter id="pencilTexture" x="-20%" y="-20%" width="140%" height="140%">
          <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" result="noise" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="1.5" xChannelSelector="R" yChannelSelector="G" />
        </filter>
        <linearGradient id="brainGradBlue" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0a34bd" />
          <stop offset="100%" stopColor="#1a4fd0" />
        </linearGradient>
        <linearGradient id="brainGradKhaki" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#6b7b3a" />
          <stop offset="100%" stopColor="#8a9f4a" />
        </linearGradient>
        <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="2" dy="2" stdDeviation="2" floodOpacity="0.3" />
        </filter>
      </defs>
      
      {/* Brain outline - pencil sketch style */}
      <ellipse cx="50" cy="50" rx="42" ry="38" fill="none" stroke="#333" strokeWidth="1.5" filter="url(#pencilTexture)" opacity="0.8" />
      <ellipse cx="50" cy="50" rx="42" ry="38" fill="none" stroke="#666" strokeWidth="0.5" strokeDasharray="2,3" opacity="0.4" />
      
      {/* Left hemisphere folds - khaki */}
      <path
        d="M25 35 Q35 28 42 38 Q48 48 38 58 Q28 65 22 52 Q16 40 25 35"
        fill="url(#brainGradKhaki)"
        filter="url(#shadow)"
        opacity="0.95"
      />
      <path
        d="M30 58 Q42 52 48 65 Q44 78 32 76 Q20 74 22 64 Q24 54 30 58"
        fill="url(#brainGradKhaki)"
        filter="url(#shadow)"
        opacity="0.9"
      />
      
      {/* Right hemisphere folds - royal blue */}
      <path
        d="M75 35 Q84 40 80 52 Q76 65 62 58 Q52 48 58 38 Q65 28 75 35"
        fill="url(#brainGradBlue)"
        filter="url(#shadow)"
        opacity="0.95"
      />
      <path
        d="M70 58 Q76 54 78 64 Q80 74 68 76 Q56 78 52 65 Q58 52 70 58"
        fill="url(#brainGradBlue)"
        filter="url(#shadow)"
        opacity="0.9"
      />
      
      {/* Top fold - royal blue */}
      <path
        d="M50 15 Q68 22 62 38 Q56 50 50 48 Q44 50 38 38 Q32 22 50 15"
        fill="url(#brainGradBlue)"
        filter="url(#shadow)"
        opacity="0.95"
      />
      
      {/* Center fold - khaki */}
      <path
        d="M44 42 Q50 36 56 42 Q62 50 56 58 Q50 64 44 58 Q38 50 44 42"
        fill="url(#brainGradKhaki)"
        filter="url(#shadow)"
        opacity="0.9"
      />
      
      {/* Pencil texture lines */}
      <path d="M30 30 Q40 35 35 45" fill="none" stroke="#333" strokeWidth="0.3" opacity="0.3" />
      <path d="M70 30 Q60 35 65 45" fill="none" stroke="#333" strokeWidth="0.3" opacity="0.3" />
      <path d="M50 20 Q52 30 50 40" fill="none" stroke="#333" strokeWidth="0.3" opacity="0.3" />
      <path d="M35 65 Q45 60 50 70" fill="none" stroke="#333" strokeWidth="0.3" opacity="0.3" />
      <path d="M65 65 Q55 60 50 70" fill="none" stroke="#333" strokeWidth="0.3" opacity="0.3" />
      
      {/* Subtle shading for 3D effect */}
      <ellipse cx="35" cy="40" rx="8" ry="6" fill="white" opacity="0.15" />
      <ellipse cx="65" cy="40" rx="8" ry="6" fill="white" opacity="0.15" />
    </svg>
  )
}
