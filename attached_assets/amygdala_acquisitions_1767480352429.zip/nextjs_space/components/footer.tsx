import Link from 'next/link'
import { Mail } from 'lucide-react'
import BrainLogo from './brain-logo'

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12 mt-20">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row justify-between items-start gap-8">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <BrainLogo className="w-10 h-10" />
              <span className="font-bold text-lg tracking-wide">AMYGDALA ACQUISITIONS</span>
            </div>
            <p className="text-gray-400 max-w-sm text-sm">
              Psychology-driven acquisition systems that generate leads, nurture prospects, and close deals.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-8 sm:gap-16">
            <div>
              <h4 className="font-semibold mb-3">Navigation</h4>
              <nav className="flex flex-col gap-2">
                <Link href="/" className="text-gray-400 hover:text-white transition-colors">Home</Link>
                <Link href="/what-we-do" className="text-gray-400 hover:text-white transition-colors">What We Do</Link>
                <Link href="/services" className="text-gray-400 hover:text-white transition-colors">Services</Link>
              </nav>
            </div>

            <div>
              <h4 className="font-semibold mb-3">Contact</h4>
              <a
                href="mailto:strategy@amygdalaacquisitions.co.uk"
                className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
              >
                <Mail size={16} />
                strategy@amygdalaacquisitions.co.uk
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-10 pt-6 text-center text-gray-500 text-sm">
          © {new Date().getFullYear()} Amygdala Acquisitions. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
