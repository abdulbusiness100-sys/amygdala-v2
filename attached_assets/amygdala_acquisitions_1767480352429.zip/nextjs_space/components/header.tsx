'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { Menu, X } from 'lucide-react'
import BrainLogo from './brain-logo'

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window?.scrollY > 20)
    }
    window?.addEventListener?.('scroll', handleScroll)
    return () => window?.removeEventListener?.('scroll', handleScroll)
  }, [])

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/what-we-do', label: 'What We Do' },
    { href: '/services', label: 'Services' },
  ]

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/90 backdrop-blur-md shadow-md'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <Link href="/" className="flex items-center gap-2">
            <BrainLogo className="w-10 h-10 sm:w-12 sm:h-12" />
            <span className="font-bold text-sm sm:text-base text-gray-900 hidden sm:block tracking-wide">
              AMYGDALA ACQUISITIONS
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {navLinks?.map?.((link) => (
              <Link
                key={link?.href ?? ''}
                href={link?.href ?? '/'}
                className="text-gray-700 hover:text-royal transition-colors font-medium"
              >
                {link?.label ?? ''}
              </Link>
            )) ?? []}
            <Link
              href="/services#book-call"
              className="bg-royal text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-royal-dark transition-colors shadow-lg shadow-royal/30"
            >
              Book Strategy Call
            </Link>
          </nav>

          <button
            className="md:hidden p-2 text-gray-700"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden bg-white/95 backdrop-blur-md absolute top-full left-0 right-0 shadow-lg">
            <nav className="flex flex-col p-4 gap-3">
              {navLinks?.map?.((link) => (
                <Link
                  key={link?.href ?? ''}
                  href={link?.href ?? '/'}
                  className="text-gray-700 hover:text-royal py-2 font-medium"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link?.label ?? ''}
                </Link>
              )) ?? []}
              <Link
                href="/services#book-call"
                className="bg-royal text-white px-5 py-3 rounded-lg font-semibold text-center mt-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Book Strategy Call
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
