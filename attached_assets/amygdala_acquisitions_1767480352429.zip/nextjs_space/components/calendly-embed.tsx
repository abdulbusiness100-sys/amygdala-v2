'use client'

import { useEffect } from 'react'

export default function CalendlyEmbed() {
  useEffect(() => {
    const script = document.createElement('script')
    script.src = 'https://assets.calendly.com/assets/external/widget.js'
    script.async = true
    document?.body?.appendChild?.(script)

    return () => {
      document?.body?.removeChild?.(script)
    }
  }, [])

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
      <div
        className="calendly-inline-widget"
        data-url="https://calendly.com/spidxr253/30min?hide_event_type_details=1&hide_gdpr_banner=1&background_color=fdfdfd&text_color=1611c3&primary_color=1a6909"
        style={{ minWidth: '320px', height: '700px' }}
      />
    </div>
  )
}
