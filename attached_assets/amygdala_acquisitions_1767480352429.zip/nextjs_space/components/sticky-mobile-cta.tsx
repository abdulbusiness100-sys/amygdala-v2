'use client'

import Link from 'next/link'
import { Phone } from 'lucide-react'
import { useState, useEffect } from 'react'

export default function StickyMobileCTA() {
  const [show, setShow] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setShow((window?.scrollY ?? 0) > 300)
    }
    window?.addEventListener?.('scroll', handleScroll)
    return () => window?.removeEventListener?.('scroll', handleScroll)
  }, [])

  if (!show) return null

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-royal p-3 shadow-2xl">
      <Link
        href="/services#book-call"
        className="flex items-center justify-center gap-2 text-white font-semibold py-2"
      >
        <Phone size={18} />
        Book Your Strategy Call
      </Link>
    </div>
  )
}
