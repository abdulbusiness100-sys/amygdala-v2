import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Header from '@/components/header'
import Footer from '@/components/footer'
import StickyMobileCTA from '@/components/sticky-mobile-cta'

export const dynamic = "force-dynamic"

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXTAUTH_URL || 'https://www.amygdalaacquisitions.co.uk'),
  title: 'Amygdala Acquisitions | Psychology-Driven Growth Systems',
  description: 'Full-stack acquisition and growth systems powered by psychology, consumer behaviour, data, and AI. Generate leads, nurture prospects, book calls, and close deals.',
  keywords: 'lead generation, client acquisition, growth systems, AI automation, business growth, sales systems',
  openGraph: {
    title: 'Amygdala Acquisitions | Psychology-Driven Growth Systems',
    description: 'Full-stack acquisition and growth systems powered by psychology, consumer behaviour, data, and AI.',
    images: ['/og-image.png'],
    type: 'website',
  },
  icons: {
    icon: '/favicon.svg',
    shortcut: '/favicon.svg',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <script src="https://apps.abacus.ai/chatllm/appllm-lib.js"></script>
      </head>
      <body className={`${inter.className} bg-cream grain-bg min-h-screen`}>
        <Header />
        <main>{children}</main>
        <Footer />
        <StickyMobileCTA />
      </body>
    </html>
  )
}
