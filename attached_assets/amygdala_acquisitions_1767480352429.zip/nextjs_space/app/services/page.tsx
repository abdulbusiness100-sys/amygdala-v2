import Link from 'next/link'
import { ArrowRight, CheckCircle2, X, Sparkles } from 'lucide-react'
import ScrollReveal from '@/components/scroll-reveal'
import LeadForm from '@/components/lead-form'
import CalendlyEmbed from '@/components/calendly-embed'
import FAQAccordion from '@/components/faq-accordion'

export default function ServicesPage() {
  const services = [
    {
      name: 'Amygdala',
      tagline: 'DONE WITH YOU',
      description: 'We build the assets, you run the controls. Perfect for teams with existing marketing staff.',
      features: [
        'System Audit',
        'Asset Creation',
        'CRM Setup',
        'Weekly Consulting',
      ],
      cta: 'Book Consult',
      gradient: 'from-white to-gray-50',
      borderGradient: 'border-gray-200',
      textColor: 'text-gray-900',
      popular: false,
    },
    {
      name: 'Medulla',
      tagline: 'DONE FOR YOU',
      description: 'Complete takeover. We build, run, and optimize the entire acquisition engine.',
      features: [
        'Everything in Amygdala',
        'Full Media Buying',
        'Copywriting & Creative',
        '24/7 Optimization',
        'Guaranteed Lead Volume',
      ],
      cta: 'Apply Now',
      gradient: 'from-royal via-royal to-royal/95',
      borderGradient: 'border-royal',
      textColor: 'text-white',
      popular: true,
    },
    {
      name: 'Cerebral',
      tagline: 'EXECUTIVE PARTNER',
      description: 'Fractional CMO & Growth Team implementation for enterprise scaling.',
      features: [
        'Full Team Access',
        'Strategy Workshops',
        'Revenue Share Model',
        'Custom Tech Stack',
      ],
      cta: 'Contact Sales',
      gradient: 'from-white to-gray-50',
      borderGradient: 'border-gray-200',
      textColor: 'text-gray-900',
      popular: false,
    },
  ]

  const comparisonFeatures = [
    { feature: 'System Blueprints & Templates', amygdala: true, medulla: true, cerebral: true },
    { feature: 'Strategy Calls', amygdala: 'Weekly', medulla: 'Weekly', cerebral: 'Weekly + On-Demand' },
    { feature: 'Done-For-You Build', amygdala: false, medulla: true, cerebral: true },
    { feature: 'Live Dashboards', amygdala: false, medulla: true, cerebral: true },
    { feature: 'AI Automation Setup', amygdala: 'Training Only', medulla: true, cerebral: true },
    { feature: 'Dedicated Account Manager', amygdala: false, medulla: true, cerebral: true },
    { feature: 'Executive Strategy Partnership', amygdala: false, medulla: false, cerebral: true },
    { feature: 'Board/Investor Reporting', amygdala: false, medulla: false, cerebral: true },
    { feature: 'Priority Support', amygdala: false, medulla: false, cerebral: true },
  ]

  const faqs = [
    {
      question: 'How long before I see results?',
      answer: 'Most clients see measurable improvements within the first 4-6 weeks. Full system implementation typically takes 6-8 weeks, with optimization continuing thereafter.',
    },
    {
      question: 'What industries do you work with?',
      answer: 'We specialize in B2B services, agencies, consultancies, SaaS, and high-ticket B2C. If your business relies on lead generation and sales calls, we can help.',
    },
    {
      question: 'Do I need technical skills?',
      answer: 'No. We handle all the technical implementation. For the Amygdala (Done With You) tier, we provide training and templates that anyone can follow.',
    },
    {
      question: "What's the minimum commitment?",
      answer: 'We recommend a minimum of 3 months to see full results, but we offer flexible arrangements based on your needs and goals.',
    },
    {
      question: 'What tools and platforms do you use?',
      answer: "We work with industry-leading tools including GoHighLevel, ActiveCampaign, HubSpot, Calendly, and custom AI solutions. We'll recommend the best stack for your specific situation.",
    },
    {
      question: 'How is this different from a marketing agency?',
      answer: "We don't just run ads or manage campaigns. We build complete acquisition systems grounded in behavioral psychology, with AI automation and real-time data. It's a holistic approach to growth, not a single-channel tactic.",
    },
  ]

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-900 via-gray-900 to-royal/30 relative">
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at 20% 80%, rgba(107, 123, 58, 0.3) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(10, 52, 189, 0.3) 0%, transparent 50%)' }} />
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 text-center relative z-10">
          <ScrollReveal>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-khaki via-white to-royal animate-gradient-shift">Partnership Models</span>
            </h1>
            <p className="text-gray-300 text-lg sm:text-xl max-w-3xl mx-auto">
              Choose how you want to deploy the engine.
            </p>
          </ScrollReveal>
        </div>
      </section>

      {/* Service Tiers - Enhanced 3D Glass Cards */}
      <section className="py-24 bg-gradient-to-b from-gray-100 to-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="grid md:grid-cols-3 gap-6">
            {services?.map?.((service, index) => (
              <ScrollReveal key={service?.name ?? index} delay={index * 150}>
                <div className={`relative h-full`}>
                  {service?.popular && (
                    <div className="absolute -top-3 right-6 z-20">
                      <div className="bg-khaki text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-lg flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        POPULAR
                      </div>
                    </div>
                  )}
                  <div 
                    className={`card-3d h-full rounded-3xl overflow-hidden border-2 ${
                      service?.popular 
                        ? 'bg-gradient-to-br from-royal via-royal to-royal/90 border-royal shadow-2xl shadow-royal/20' 
                        : 'bg-white border-gray-200 hover:border-gray-300'
                    }`}
                    style={{
                      backdropFilter: service?.popular ? 'none' : 'blur(20px)',
                    }}
                  >
                    <div className="p-8">
                      <div className={`mb-6 ${service?.popular ? 'text-white' : 'text-gray-900'}`}>
                        <h3 className="text-3xl font-bold mb-1">{service?.name ?? ''}</h3>
                        <p className={`text-sm font-semibold tracking-wider ${service?.popular ? 'text-white/70' : 'text-gray-500'}`}>
                          {service?.tagline ?? ''}
                        </p>
                      </div>
                      
                      <p className={`mb-8 ${service?.popular ? 'text-white/90' : 'text-gray-600'}`}>
                        {service?.description ?? ''}
                      </p>
                      
                      <ul className="space-y-3 mb-8">
                        {service?.features?.map?.((feature, i) => (
                          <li key={i} className="flex items-center gap-3">
                            <CheckCircle2 className={`w-5 h-5 flex-shrink-0 ${service?.popular ? 'text-khaki' : 'text-royal'}`} />
                            <span className={service?.popular ? 'text-white' : 'text-gray-700'}>{feature ?? ''}</span>
                          </li>
                        )) ?? []}
                      </ul>
                      
                      <a
                        href="#book-call"
                        className={`block w-full py-4 rounded-xl font-semibold text-center transition-all duration-300 ${
                          service?.popular 
                            ? 'bg-white text-royal hover:bg-gray-100 shadow-lg' 
                            : 'bg-gray-100 text-gray-900 hover:bg-gray-200 border border-gray-200'
                        }`}
                      >
                        {service?.cta ?? 'Get Started'}
                      </a>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            )) ?? []}
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-center text-gray-900 mb-12">
              Compare <span className="text-transparent bg-clip-text bg-gradient-to-r from-royal to-khaki">All Tiers</span>
            </h2>
          </ScrollReveal>

          <ScrollReveal delay={200}>
            <div className="overflow-x-auto">
              <table className="w-full bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
                <thead>
                  <tr className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white">
                    <th className="text-left p-5 font-semibold">Feature</th>
                    <th className="text-center p-5 font-semibold">Amygdala</th>
                    <th className="text-center p-5 font-semibold bg-royal/30">Medulla</th>
                    <th className="text-center p-5 font-semibold">Cerebral</th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonFeatures?.map?.((row, index) => (
                    <tr key={index} className={`${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-gray-100 transition-colors`}>
                      <td className="p-5 text-gray-700 font-medium">{row?.feature ?? ''}</td>
                      <td className="p-5 text-center">
                        {row?.amygdala === true ? (
                          <CheckCircle2 className="w-5 h-5 text-green-500 mx-auto" />
                        ) : row?.amygdala === false ? (
                          <X className="w-5 h-5 text-gray-300 mx-auto" />
                        ) : (
                          <span className="text-gray-600 text-sm">{String(row?.amygdala ?? '')}</span>
                        )}
                      </td>
                      <td className="p-5 text-center bg-royal/5">
                        {row?.medulla === true ? (
                          <CheckCircle2 className="w-5 h-5 text-green-500 mx-auto" />
                        ) : row?.medulla === false ? (
                          <X className="w-5 h-5 text-gray-300 mx-auto" />
                        ) : (
                          <span className="text-gray-600 text-sm">{String(row?.medulla ?? '')}</span>
                        )}
                      </td>
                      <td className="p-5 text-center">
                        {row?.cerebral === true ? (
                          <CheckCircle2 className="w-5 h-5 text-green-500 mx-auto" />
                        ) : row?.cerebral === false ? (
                          <X className="w-5 h-5 text-gray-300 mx-auto" />
                        ) : (
                          <span className="text-gray-600 text-sm">{String(row?.cerebral ?? '')}</span>
                        )}
                      </td>
                    </tr>
                  )) ?? []}
                </tbody>
              </table>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Lead Form */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white" id="audit">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <ScrollReveal>
              <div>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                  Get Your Free <span className="text-transparent bg-clip-text bg-gradient-to-r from-khaki to-royal">Growth Audit</span>
                </h2>
                <p className="text-gray-600 text-lg mb-8">
                  Tell us about your business and we&apos;ll identify the biggest opportunities to improve your acquisition system. No obligation, just actionable insights.
                </p>
                <ul className="space-y-4">
                  {[
                    'Identify leaks in your current funnel',
                    'Discover quick wins for immediate improvement',
                    'Get a custom roadmap for your business',
                    'Learn which service tier fits your needs',
                  ]?.map?.((item, i) => (
                    <li key={i} className="flex items-center gap-4">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-royal to-royal/80 flex items-center justify-center">
                        <CheckCircle2 className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-gray-700">{item ?? ''}</span>
                    </li>
                  )) ?? []}
                </ul>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <LeadForm />
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Calendly Embed */}
      <section className="py-24 bg-white" id="book-call">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-center text-gray-900 mb-4">
              Book Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-royal to-khaki">Strategy Call</span>
            </h2>
            <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12 text-lg">
              Ready to transform your acquisition? Choose a time that works for you.
            </p>
          </ScrollReveal>

          <ScrollReveal delay={200}>
            <CalendlyEmbed />
          </ScrollReveal>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-[800px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-center text-gray-900 mb-12">
              Frequently Asked <span className="text-khaki">Questions</span>
            </h2>
          </ScrollReveal>

          <FAQAccordion faqs={faqs} />
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-gradient-to-br from-gray-900 via-gray-900 to-royal/30 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-royal/20 to-transparent" />
          <div className="absolute bottom-0 left-0 w-1/2 h-full bg-gradient-to-r from-khaki/10 to-transparent" />
        </div>
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 text-center relative z-10">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
              Start Building Your <span className="text-khaki">Growth Machine</span> Today
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-10">
              Whether you want to learn, have it done for you, or need executive-level partnership—we have a path for you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="#audit"
                className="glass text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-white/20 transition-all duration-300"
              >
                Get Free Audit
              </a>
              <a
                href="#book-call"
                className="group bg-gradient-to-r from-khaki to-khaki/90 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-2xl hover:shadow-khaki/30 transition-all duration-300 flex items-center justify-center gap-2"
              >
                Book Strategy Call
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
