import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, Target, Users, TrendingUp, Calendar, CheckCircle2, Zap, Brain, BarChart3, Bot, Clock, FileText, Settings, LineChart, MessageSquare, Phone } from 'lucide-react'
import ScrollReveal from '@/components/scroll-reveal'

export default function WhatWeDoPage() {
  const systemDiagram = [
    { icon: Target, label: 'Lead Capture', description: 'Multi-channel acquisition funnels', color: 'bg-royal' },
    { icon: Brain, label: 'Behavioral Scoring', description: 'AI-powered lead qualification', color: 'bg-khaki' },
    { icon: MessageSquare, label: 'Nurture Sequences', description: 'Psychology-driven follow-up', color: 'bg-royal' },
    { icon: Calendar, label: 'Smart Booking', description: 'Automated calendar management', color: 'bg-khaki' },
    { icon: Phone, label: 'Sales Enablement', description: 'Conversion-optimized handoff', color: 'bg-royal' },
    { icon: LineChart, label: 'Live Dashboard', description: 'Real-time performance data', color: 'bg-khaki' },
  ]

  const weeklyBreakdown = [
    {
      week: 'Week 1-2',
      title: 'Discovery & Audit',
      tasks: [
        'Complete business audit and opportunity mapping',
        'Customer journey analysis and friction points',
        'Competitive landscape review',
        'Define KPIs and success metrics',
      ],
    },
    {
      week: 'Week 3-4',
      title: 'Strategy & Architecture',
      tasks: [
        'Behavioral funnel design and mapping',
        'Copy and messaging framework creation',
        'Technology stack selection',
        'Integration planning and requirements',
      ],
    },
    {
      week: 'Week 5-6',
      title: 'Build & Configure',
      tasks: [
        'Landing page and funnel construction',
        'Email/SMS sequence development',
        'CRM and automation setup',
        'AI chatbot and qualification flows',
      ],
    },
    {
      week: 'Week 7-8',
      title: 'Launch & Optimize',
      tasks: [
        'Soft launch and testing phase',
        'Tracking and attribution setup',
        'Performance monitoring and tweaks',
        'Team training and documentation',
      ],
    },
    {
      week: 'Week 9+',
      title: 'Scale & Iterate',
      tasks: [
        'A/B testing and optimization cycles',
        'Channel expansion strategies',
        'Retention system activation',
        'Monthly performance reviews',
      ],
    },
  ]

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="pt-32 pb-20 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 text-center">
          <ScrollReveal>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
              We Build <span className="text-khaki">Complete</span> Acquisition Systems
            </h1>
            <p className="text-gray-300 text-lg sm:text-xl max-w-3xl mx-auto">
              From first touch to closed deal, we engineer every step of your client journey using psychology, data, and AI.
            </p>
          </ScrollReveal>
        </div>
      </section>

      {/* System Diagram */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl font-bold text-center text-gray-900 mb-4">
              The <span className="text-royal">Full-Stack</span> System
            </h2>
            <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
              Every component works together to create a seamless acquisition machine.
            </p>
          </ScrollReveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {systemDiagram?.map?.((item, index) => {
              const IconComponent = item?.icon
              return (
                <ScrollReveal key={item?.label ?? index} delay={index * 100}>
                  <div className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-all hover:-translate-y-1">
                    <div className={`w-14 h-14 rounded-xl ${item?.color ?? 'bg-royal'} flex items-center justify-center mb-4`}>
                      {IconComponent && <IconComponent className="w-7 h-7 text-white" />}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{item?.label ?? ''}</h3>
                    <p className="text-gray-600">{item?.description ?? ''}</p>
                  </div>
                </ScrollReveal>
              )
            }) ?? []}
          </div>

          {/* Flow Arrows */}
          <ScrollReveal delay={600}>
            <div className="mt-12 flex justify-center">
              <div className="bg-gradient-to-r from-royal via-khaki to-royal h-2 rounded-full w-full max-w-2xl" />
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Deep Dive: The 3 Pillars */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl font-bold text-center text-gray-900 mb-12">
              Our Three <span className="text-khaki">Core Pillars</span>
            </h2>
          </ScrollReveal>

          {/* Pillar 1 */}
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
            <ScrollReveal>
              <div className="relative aspect-square max-w-md mx-auto rounded-2xl overflow-hidden">
                <Image
                  src="https://cdn.abacus.ai/images/2a64a243-035d-4984-9770-1335c76c5f36.png"
                  alt="Behavioral Design"
                  fill
                  className="object-cover"
                />
              </div>
            </ScrollReveal>
            <ScrollReveal delay={200}>
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <Brain className="w-8 h-8 text-royal" />
                  <h3 className="text-2xl font-bold text-gray-900">Behavioral Design</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  Every message, every page, every interaction is engineered using proven psychological principles. We leverage cognitive biases, emotional triggers, and persuasion frameworks to make your funnel irresistible.
                </p>
                <ul className="space-y-3">
                  {['Loss aversion and urgency triggers', 'Social proof positioning', 'Cognitive ease optimization', 'Commitment and consistency patterns']?.map?.((item, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-khaki flex-shrink-0" />
                      <span className="text-gray-700">{item ?? ''}</span>
                    </li>
                  )) ?? []}
                </ul>
              </div>
            </ScrollReveal>
          </div>

          {/* Pillar 2 */}
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
            <ScrollReveal delay={200} className="order-2 lg:order-1">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <BarChart3 className="w-8 h-8 text-khaki" />
                  <h3 className="text-2xl font-bold text-gray-900">Data & Forecasting</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  Real-time visibility into every metric that matters. Know exactly where each lead is, what\'s converting, and where to invest for maximum return.
                </p>
                <ul className="space-y-3">
                  {['Live performance dashboards', 'Predictive lead scoring', 'Attribution modeling', 'Revenue forecasting']?.map?.((item, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-royal flex-shrink-0" />
                      <span className="text-gray-700">{item ?? ''}</span>
                    </li>
                  )) ?? []}
                </ul>
              </div>
            </ScrollReveal>
            <ScrollReveal className="order-1 lg:order-2">
              <div className="relative aspect-square max-w-md mx-auto rounded-2xl overflow-hidden">
                <Image
                  src="https://cdn.abacus.ai/images/b39140ee-1eb3-4c31-9619-1858913c3c5e.png"
                  alt="Data & Forecasting"
                  fill
                  className="object-cover"
                />
              </div>
            </ScrollReveal>
          </div>

          {/* Pillar 3 */}
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <ScrollReveal>
              <div className="relative aspect-square max-w-md mx-auto rounded-2xl overflow-hidden">
                <Image
                  src="https://cdn.abacus.ai/images/bd30032f-52b2-4fb3-a044-b5fdc0450189.png"
                  alt="AI Automation"
                  fill
                  className="object-cover"
                />
              </div>
            </ScrollReveal>
            <ScrollReveal delay={200}>
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <Bot className="w-8 h-8 text-royal" />
                  <h3 className="text-2xl font-bold text-gray-900">AI Automation</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  Intelligent systems that work 24/7. From initial qualification to appointment booking, AI handles the repetitive work while you focus on closing.
                </p>
                <ul className="space-y-3">
                  {['AI chatbots for qualification', 'Smart email/SMS sequences', 'Automated appointment booking', 'Intelligent follow-up timing']?.map?.((item, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-khaki flex-shrink-0" />
                      <span className="text-gray-700">{item ?? ''}</span>
                    </li>
                  )) ?? []}
                </ul>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Week-by-Week Breakdown */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl font-bold text-center text-gray-900 mb-4">
              Week-by-Week <span className="text-royal">Implementation</span>
            </h2>
            <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
              A transparent timeline so you know exactly what happens and when.
            </p>
          </ScrollReveal>

          <div className="relative">
            {/* Timeline line */}
            <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-royal via-khaki to-royal" />

            {weeklyBreakdown?.map?.((week, index) => (
              <ScrollReveal key={week?.week ?? index} delay={index * 100}>
                <div className={`relative grid lg:grid-cols-2 gap-8 mb-8 ${index % 2 === 0 ? '' : 'lg:direction-rtl'}`}>
                  <div className={`${index % 2 === 0 ? 'lg:pr-12 lg:text-right' : 'lg:pl-12 lg:col-start-2'}`}>
                    <div className={`bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow ${index % 2 === 0 ? '' : ''}`}>
                      <div className="flex items-center gap-3 mb-3 lg:justify-start">
                        <Clock className={`w-5 h-5 ${index % 2 === 0 ? 'text-royal' : 'text-khaki'}`} />
                        <span className="text-sm font-semibold text-gray-500">{week?.week ?? ''}</span>
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-4">{week?.title ?? ''}</h3>
                      <ul className="space-y-2">
                        {week?.tasks?.map?.((task, i) => (
                          <li key={i} className="flex items-start gap-2 text-gray-600">
                            <CheckCircle2 className={`w-4 h-4 mt-1 flex-shrink-0 ${index % 2 === 0 ? 'text-royal' : 'text-khaki'}`} />
                            <span>{task ?? ''}</span>
                          </li>
                        )) ?? []}
                      </ul>
                    </div>
                  </div>

                  {/* Timeline dot */}
                  <div className="hidden lg:flex absolute left-1/2 top-6 -translate-x-1/2 w-6 h-6 rounded-full bg-white border-4 border-royal" />
                </div>
              </ScrollReveal>
            )) ?? []}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 text-center">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              See Which System Fits <span className="text-khaki">Your Business</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-8">
              We offer three tiers of service to match your goals, budget, and involvement level.
            </p>
            <Link
              href="/services"
              className="inline-flex items-center gap-2 bg-royal text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-royal-dark transition-all shadow-xl shadow-royal/30"
            >
              Explore Our Services
              <ArrowRight size={20} />
            </Link>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
