import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight, Target, TrendingUp, Users, Zap, BarChart3, Bot, Brain, CheckCircle2, Calendar, Wrench, Rocket, Sparkles, LineChart, Settings } from 'lucide-react'
import ScrollReveal from '@/components/scroll-reveal'
import AnimatedCounter from '@/components/animated-counter'

export default function HomePage() {
  const processSteps = [
    { icon: Target, label: 'ATTRACT', color: 'from-royal to-royal/80' },
    { icon: Users, label: 'QUALIFY', color: 'from-khaki to-khaki/80' },
    { icon: TrendingUp, label: 'NURTURE', color: 'from-royal to-royal/80' },
    { icon: Calendar, label: 'BOOK', color: 'from-khaki to-khaki/80' },
    { icon: CheckCircle2, label: 'CLOSE', color: 'from-royal to-royal/80' },
    { icon: LineChart, label: 'RETAIN', color: 'from-khaki to-khaki/80' },
  ]

  const pillars = [
    {
      icon: Brain,
      title: 'Behavioral Design',
      description: 'Every touchpoint is engineered to trigger specific psychological responses that build trust and authority.',
      color: 'royal',
      gradient: 'from-royal/10 to-royal/5',
    },
    {
      icon: BarChart3,
      title: 'Data & Forecasting',
      description: 'No guesswork. We use predictive analytics to model your growth trajectory before spending a dollar.',
      color: 'khaki',
      gradient: 'from-khaki/10 to-khaki/5',
    },
    {
      icon: Bot,
      title: 'AI Automation',
      description: 'Human connection where it matters. Ruthless automation everywhere else to scale without burnout.',
      color: 'royal',
      gradient: 'from-royal/10 to-royal/5',
    },
  ]

  const testimonials = [
    {
      initials: 'ZE',
      role: 'CEO',
      date: '15 Jan 2025',
      text: 'Finance restructure saved us £20K. Their CFO advisory is worth 10x the investment.',
      color: 'bg-green-500',
    },
    {
      initials: 'SM',
      role: 'Dental Practice Manager',
      date: '03 Feb 2025',
      text: 'Cut overhead in all 11 locations using their AI booking. Game changer.',
      color: 'bg-pink-500',
    },
    {
      initials: 'SH',
      role: 'Clinic Owner',
      date: '22 Mar 2025',
      text: 'Hired our entire C-suite in 3 weeks through their executive partner program.',
      color: 'bg-teal-500',
    },
  ]

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20">
        <div className="absolute inset-0 z-0 bg-gradient-to-br from-gray-900 via-gray-900 to-royal/30">
          <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at 20% 80%, rgba(107, 123, 58, 0.3) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(10, 52, 189, 0.3) 0%, transparent 50%)' }} />
          {/* Animated gradient orbs */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-royal/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-khaki/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        </div>

        <div className="relative z-10 max-w-[1200px] mx-auto px-4 sm:px-6 py-20 text-center">
          <ScrollReveal>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-6">
              <Sparkles className="w-4 h-4 text-khaki" />
              <span className="text-khaki font-medium text-sm tracking-wider uppercase">Psychology • Data • AI</span>
            </div>
          </ScrollReveal>
          
          <ScrollReveal delay={100}>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-6 leading-tight">
              Build & Scale With
              <span className="block mt-2 text-transparent bg-clip-text bg-gradient-to-r from-khaki via-white to-royal animate-gradient-shift">
                Empirical Growth Systems
              </span>
            </h1>
          </ScrollReveal>

          <ScrollReveal delay={200}>
            <p className="text-gray-300 text-lg sm:text-xl max-w-2xl mx-auto mb-10">
              We replace guesswork with granular behavioral science.<br/>
              Stop marketing. Start engineering your growth.
            </p>
          </ScrollReveal>

          <ScrollReveal delay={300}>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/services#book-call"
                className="group bg-gradient-to-r from-khaki to-khaki/90 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-2xl hover:shadow-khaki/30 transition-all duration-300 flex items-center justify-center gap-2 animate-pulse-glow"
              >
                Start Your Engine
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="/what-we-do"
                className="glass text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-white/20 transition-all duration-300"
              >
                See The Mechanism
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Process Flow */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="flex flex-wrap justify-center gap-4 md:gap-2">
            {processSteps?.map?.((step, index) => {
              const IconComponent = step?.icon
              return (
                <ScrollReveal key={step?.label ?? index} delay={index * 80}>
                  <div className="flex items-center">
                    <div className={`card-3d bg-gradient-to-br ${step?.color ?? ''} rounded-2xl p-5 text-center min-w-[100px] cursor-pointer`}>
                      <div className="w-12 h-12 mx-auto mb-2 bg-white/20 rounded-xl flex items-center justify-center">
                        {IconComponent && <IconComponent className="w-6 h-6 text-white" />}
                      </div>
                      <p className="text-white font-bold text-xs tracking-wider">{step?.label ?? ''}</p>
                    </div>
                    {index < (processSteps?.length ?? 0) - 1 && (
                      <div className="hidden md:flex items-center px-2">
                        <div className="w-8 h-0.5 bg-gradient-to-r from-royal to-khaki" />
                        <div className="w-0 h-0 border-t-4 border-b-4 border-l-4 border-transparent border-l-khaki" />
                      </div>
                    )}
                  </div>
                </ScrollReveal>
              )
            }) ?? []}
          </div>
        </div>
      </section>

      {/* Problem Section - Redesigned */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <ScrollReveal>
              <div>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
                  If you&apos;re posting but not <span className="text-khaki">converting...</span>
                </h2>
                <p className="text-gray-600 text-lg mb-6">
                  Your &quot;marketing&quot; is just noise. The market doesn&apos;t need more content. It needs clarity. Most firms rely on hope-marketing: throw content at the wall and pray for a lead.
                </p>
                <div className="p-6 bg-white rounded-2xl border-l-4 border-royal shadow-lg">
                  <p className="text-gray-700 italic text-lg">
                    We don&apos;t do hope. We build deterministic systems that turn strangers into high-value clients predictably.
                  </p>
                </div>
              </div>
            </ScrollReveal>
            
            <ScrollReveal delay={200}>
              <div className="grid grid-cols-2 gap-4">
                <div className="card-3d bg-white rounded-2xl p-6 border border-gray-100">
                  <div className="text-4xl font-bold text-khaki mb-2">0%</div>
                  <p className="text-gray-600 text-sm">Predictability in your current pipeline</p>
                </div>
                <div className="card-3d bg-white rounded-2xl p-6 border border-gray-100">
                  <div className="text-4xl font-bold text-khaki mb-2">100h+</div>
                  <p className="text-gray-600 text-sm">Wasted on unqualified calls monthly</p>
                </div>
                <div className="col-span-2 card-3d bg-gradient-to-br from-royal to-royal/90 rounded-2xl p-6 text-white">
                  <h3 className="text-xl font-bold mb-2">The Fix</h3>
                  <p className="text-white/90">A closed-loop system that qualifies leads before you ever speak to them.</p>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* The Amygdala Method - Compartmentalized */}
      <section className="py-24 bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
                The <span className="text-transparent bg-clip-text bg-gradient-to-r from-royal to-khaki">Amygdala</span> Method
              </h2>
              <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                We target the reptilian brain—the decision maker. Logic validates, but emotion decides.
              </p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-3 gap-6">
            {pillars?.map?.((pillar, index) => {
              const IconComponent = pillar?.icon
              return (
                <ScrollReveal key={pillar?.title ?? index} delay={index * 150}>
                  <div className={`card-3d bg-gradient-to-br ${pillar?.gradient ?? ''} rounded-3xl p-8 h-full border border-gray-100`}>
                    <div className={`w-14 h-14 rounded-2xl bg-${pillar?.color ?? 'royal'} flex items-center justify-center mb-6 shadow-lg`} style={{ backgroundColor: pillar?.color === 'khaki' ? '#6b7b3a' : '#0a34bd' }}>
                      {IconComponent && <IconComponent className="w-7 h-7 text-white" />}
                    </div>
                    <h3 className={`text-2xl font-bold mb-4`} style={{ color: pillar?.color === 'khaki' ? '#6b7b3a' : '#0a34bd' }}>{pillar?.title ?? ''}</h3>
                    <p className="text-gray-600 text-lg leading-relaxed">{pillar?.description ?? ''}</p>
                  </div>
                </ScrollReveal>
              )
            }) ?? []}
          </div>
        </div>
      </section>

      {/* Results Section - Enhanced */}
      <section className="py-24 bg-gradient-to-br from-royal via-royal to-royal/90 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, white 1px, transparent 1px)', backgroundSize: '50px 50px' }} />
        </div>
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 relative z-10">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-center mb-4">
              Results You Can <span className="text-khaki">Measure</span>
            </h2>
            <p className="text-white/80 text-center text-lg mb-16 max-w-2xl mx-auto">
              This is what a healthy pipeline looks like.
            </p>
          </ScrollReveal>

          <div className="grid sm:grid-cols-3 gap-8">
            {[
              { value: 342, prefix: '+', label: 'QUALIFIED LEADS' },
              { value: 85, prefix: '+', label: 'BOOKED CALLS' },
              { value: 42, suffix: '%', label: 'CLOSE RATE' },
            ]?.map?.((stat, index) => (
              <ScrollReveal key={stat?.label ?? index} delay={index * 100}>
                <div className="card-3d bg-white/10 backdrop-blur-sm rounded-3xl p-8 text-center border border-white/20">
                  <div className="text-5xl sm:text-6xl font-bold text-white mb-3">
                    <AnimatedCounter end={stat?.value ?? 0} prefix={stat?.prefix ?? ''} suffix={stat?.suffix ?? ''} />
                  </div>
                  <p className="text-white/70 font-semibold tracking-wider text-sm">{stat?.label ?? ''}</p>
                </div>
              </ScrollReveal>
            )) ?? []}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-center text-gray-900 mb-4">
              Real <span className="text-royal">Results</span>
            </h2>
            <p className="text-gray-600 text-center text-lg mb-16">What our clients say about working with us.</p>
          </ScrollReveal>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials?.map?.((t, index) => (
              <ScrollReveal key={index} delay={index * 100}>
                <div className="card-3d bg-white rounded-2xl p-6 border border-gray-100">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-12 h-12 rounded-full ${t?.color ?? 'bg-gray-500'} flex items-center justify-center text-white font-bold`}>
                      {t?.initials ?? ''}
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">{t?.date ?? ''}</p>
                      <p className="font-semibold text-royal">{t?.role ?? ''}</p>
                    </div>
                  </div>
                  <p className="text-gray-700">{t?.text ?? ''}</p>
                </div>
              </ScrollReveal>
            )) ?? []}
          </div>
        </div>
      </section>

      {/* Implementation Roadmap - Mindmap Style */}
      <section className="py-24 bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-center text-gray-900 mb-4">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-royal to-khaki">Implementation</span> Roadmap
            </h2>
          </ScrollReveal>

          <div className="mt-16 relative">
            {/* Central line for desktop */}
            <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-royal via-khaki to-royal transform -translate-y-1/2" />
            
            <div className="grid md:grid-cols-3 gap-8 relative">
              {[
                { num: '01', title: 'Audit', desc: 'We tear down your current process to find the leaks.', icon: Target },
                { num: '02', title: 'Rebuild', desc: 'We engineer your new offer and acquisition assets.', icon: Settings },
                { num: '03', title: 'Rollout', desc: 'We launch, gather data, and optimize for scale.', icon: Rocket },
              ]?.map?.((phase, index) => {
                const IconComponent = phase?.icon
                return (
                  <ScrollReveal key={index} delay={index * 150}>
                    <div className="relative">
                      {/* Circle node */}
                      <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-royal/10 to-khaki/10 border-4 border-white shadow-xl flex items-center justify-center relative z-10">
                        <span className="text-2xl font-bold text-royal">{phase?.num ?? ''}</span>
                      </div>
                      <div className="card-3d bg-gray-50 rounded-2xl p-6 text-center">
                        <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-gradient-to-br from-royal to-royal/80 flex items-center justify-center">
                          {IconComponent && <IconComponent className="w-6 h-6 text-white" />}
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">{phase?.title ?? ''}</h3>
                        <p className="text-gray-600">{phase?.desc ?? ''}</p>
                      </div>
                    </div>
                  </ScrollReveal>
                )
              }) ?? []}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gray-900 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-royal/20 to-transparent" />
          <div className="absolute bottom-0 left-0 w-1/2 h-full bg-gradient-to-r from-khaki/10 to-transparent" />
        </div>
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 text-center relative z-10">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
              Ready to Build Your <span className="text-khaki">Growth Machine</span>?
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-10">
              Book a strategy call and discover how psychology-driven systems can transform your acquisition.
            </p>
            <Link
              href="/services#book-call"
              className="group inline-flex items-center gap-2 bg-gradient-to-r from-khaki to-khaki/90 text-white px-10 py-5 rounded-xl font-semibold text-lg hover:shadow-2xl hover:shadow-khaki/30 transition-all duration-300"
            >
              Book Your Strategy Call
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
