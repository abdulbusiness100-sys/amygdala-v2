import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  try {
    const body = await request?.json?.()

    const {
      name,
      email,
      phone,
      businessType,
      currentRevenue,
      mainChallenges,
      goals,
      howDidYouHear,
    } = body ?? {}

    if (!name || !email || !businessType || !currentRevenue || !mainChallenges) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const lead = await prisma?.leadSubmission?.create?.({
      data: {
        name: String(name ?? ''),
        email: String(email ?? ''),
        phone: phone ? String(phone) : null,
        businessType: String(businessType ?? ''),
        currentRevenue: String(currentRevenue ?? ''),
        mainChallenges: String(mainChallenges ?? ''),
        goals: goals ? String(goals) : null,
        howDidYouHear: howDidYouHear ? String(howDidYouHear) : null,
      },
    })

    return NextResponse.json({ success: true, id: lead?.id ?? '' })
  } catch (error) {
    console.error('Lead submission error:', error)
    return NextResponse.json(
      { error: 'Failed to submit lead' },
      { status: 500 }
    )
  }
}
